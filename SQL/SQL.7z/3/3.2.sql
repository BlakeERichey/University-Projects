select Subject, count(Num)
from Course
group by Subject;